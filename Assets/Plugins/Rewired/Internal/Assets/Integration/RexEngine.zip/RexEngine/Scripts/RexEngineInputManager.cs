﻿// Copyright (c) 2017 Augie R. Maddox, Guavaman Enterprises. All rights reserved.

#pragma warning disable 0649

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Rewired.Integration.RexEngine {

    [RequireComponent(typeof(Rewired.InputManager))]
    public sealed class RexEngineInputManager : global::RexEngine.InputManager, global::RexEngine.ITouchInputManager {

        private const string className = "Rewired Some Asset Input Manager";

        [Header("Action Mappings")]
        [Tooltip("The string name of the Rewired Action to use for the game Jump action.")]
        [SerializeField]
        private string _jumpAction = "Jump";
        [SerializeField]
        [Tooltip("The string name of the Rewired Action to use for the game Attack action.")]
        private string _attackAction = "Attack";
        [SerializeField]
        [Tooltip("The string name of the Rewired Action to use for the game Sub Attack action.")]
        private string _subAttackAction = "SubAttack";
        [SerializeField]
        [Tooltip("The string name of the Rewired Action to use for the game Dash action.")]
        private string _dashAction = "Dash";
        [SerializeField]
        [Tooltip("The string name of the Rewired Action to use for the game Run action.")]
        private string _runAction = "Run";
        [SerializeField]
        [Tooltip("The string name of the Rewired Action to use for the game Horizontal action.")]
        private string _horizontalAction = "Horizontal";
        [SerializeField]
        [Tooltip("The string name of the Rewired Action to use for the game Vertical action.")]
        private string _verticalAction = "Vertical";
        [SerializeField]
        [Tooltip("The string name of the Rewired Action to use for the game Pause action.")]
        private string _pauseAction = "Pause";

        [Header("Touch Controls")]
        [Tooltip("Link the touch controls GameObject here. This GameObject will be enabled and disabled when the touch UI is shown / hidden.")]
        [SerializeField]
        private GameObject _touchControls;

        [Tooltip("Should touch controls be hidden when a joystick is connected?")]
        [SerializeField]
        private bool _hideTouchControlsWhenJoysticksConnected = true;

        [Tooltip("Show touch controls on the following platforms.")]
        [SerializeField]
        [Rewired.Utils.Attributes.BitmaskToggle(typeof(PlatformFlags))]
        private PlatformFlags _showTouchControlsOn = PlatformFlags.Android | PlatformFlags.IOS;

        private Dictionary<int, int> _actionIds;
        private bool _initialized;
        private bool _autoTouchControlUI_isActive;
        private bool _touchControlsActiveExternal;

        public bool showTouchControls {
            get {
                return _initialized &&
                    Enabled &&
                    supportsTouchControls &&
                    _touchControlsActiveExternal &&
                    (_hideTouchControlsWhenJoysticksConnected ? _autoTouchControlUI_isActive : true);
            }
            set {
                _touchControlsActiveExternal = value;
                if(value && (!_initialized || !Enabled || !supportsTouchControls)) return;
                EvaluateTouchControlsActive();
            }
        }

        private bool supportsTouchControls {
            get {
                if(_showTouchControlsOn == PlatformFlags.None) return false;
                if(_touchControls == null) return false;

                PlatformFlags p = _showTouchControlsOn;
                if(Rewired.Utils.UnityTools.isEditor && (p & PlatformFlags.Editor) != 0) return true;

                if(!UnityEngine.Input.touchSupported) return false;

                var platform = Rewired.Utils.UnityTools.platform;
                if(platform == Rewired.Platforms.Platform.Windows) return (p & PlatformFlags.Windows) != 0;
                if(platform == Rewired.Platforms.Platform.OSX) return (p & PlatformFlags.OSX) != 0;
                if(platform == Rewired.Platforms.Platform.Linux) return (p & PlatformFlags.Linux) != 0;
                if(platform == Rewired.Platforms.Platform.iOS) return (p & PlatformFlags.IOS) != 0;
                if(platform == Rewired.Platforms.Platform.tvOS) return (p & PlatformFlags.TVOS) != 0;
                if(platform == Rewired.Platforms.Platform.Android) return (p & PlatformFlags.Android) != 0;
                if(platform == Rewired.Platforms.Platform.AmazonFireTV) return (p & PlatformFlags.AmazonFireTV) != 0;
                if(platform == Rewired.Platforms.Platform.RazerForgeTV) return (p & PlatformFlags.RazerForgeTV) != 0;
                if(platform == Rewired.Platforms.Platform.Windows81Store || platform == Rewired.Platforms.Platform.WindowsAppStore) return (p & PlatformFlags.Windows8Store) != 0;
                if(platform == Rewired.Platforms.Platform.WindowsUWP) return (p & PlatformFlags.WindowsUWP10) != 0;
                if(platform == Rewired.Platforms.Platform.WebGL) return (p & PlatformFlags.WebGL) != 0;
                if(platform == Rewired.Platforms.Platform.PS4) return (p & PlatformFlags.PS4) != 0;
                if(platform == Rewired.Platforms.Platform.PSMobile || platform == Rewired.Platforms.Platform.PSVita) return (p & PlatformFlags.PSVita) != 0;
                if(platform == Rewired.Platforms.Platform.Xbox360) return (p & PlatformFlags.Xbox360) != 0;
                if(platform == Rewired.Platforms.Platform.XboxOne) return (p & PlatformFlags.XboxOne) != 0;
                if(platform == Rewired.Platforms.Platform.SamsungTV) return (p & PlatformFlags.SamsungTV) != 0;
                if(platform == Rewired.Platforms.Platform.WiiU) return (p & PlatformFlags.WiiU) != 0;
                if(platform == Rewired.Platforms.Platform.N3DS) return (p & PlatformFlags.Nintendo3DS) != 0;
                if(platform == Rewired.Platforms.Platform.Switch) return (p & PlatformFlags.Switch) != 0;
                return (p & PlatformFlags.Unknown) != 0;
            }
        }

        protected override void Awake() {
            base.Awake();

            if(!ReInput.isReady) {
                Debug.LogError(className + ": Rewired is not initialized. You must have an active Rewired Input Manager in the scene.");
                return;
            }

            _initialized = true;

            // Cache Rewired Action ids for speed
            _actionIds = new Dictionary<int, int>();
            AddRewiredActionId(_actionIds, _jumpAction, global::RexEngine.InputAction.Jump);
            AddRewiredActionId(_actionIds, _attackAction, global::RexEngine.InputAction.Attack);
            AddRewiredActionId(_actionIds, _subAttackAction, global::RexEngine.InputAction.SubAttack);
            AddRewiredActionId(_actionIds, _dashAction, global::RexEngine.InputAction.Dash);
            AddRewiredActionId(_actionIds, _runAction, global::RexEngine.InputAction.Run);
            AddRewiredActionId(_actionIds, _horizontalAction, global::RexEngine.InputAction.MoveHorizontal);
            AddRewiredActionId(_actionIds, _verticalAction, global::RexEngine.InputAction.MoveVertical);
            AddRewiredActionId(_actionIds, _pauseAction, global::RexEngine.InputAction.Pause);

            // Set the singleton instance
            SetInstance(this);

            // Set this as the touch input manager
            touchInputManager = this;

            // Show/hide the touch UI initially
            bool showTouchControls = supportsTouchControls;
            _touchControlsActiveExternal = showTouchControls;
            SetTouchControlsActive(showTouchControls);

            if(_hideTouchControlsWhenJoysticksConnected) {
                _autoTouchControlUI_isActive = showTouchControls;
                CheckHideTouchControlsWhenJoystickConnected();
            }
        }

        protected override void OnEnable() {
            base.OnEnable();
            ReInput.ControllerConnectedEvent += OnControllerConnected;
            ReInput.ControllerDisconnectedEvent += OnControllerDisconnected;
        }

        protected override void OnDisable() {
            base.OnDisable();
            ReInput.ControllerConnectedEvent -= OnControllerConnected;
            ReInput.ControllerDisconnectedEvent -= OnControllerDisconnected;
        }

        // Public methods

        public void ToggleTouchInterface(bool show) {
            showTouchControls = show;
        }

        public override bool GetButton(int playerId, global::RexEngine.InputAction action) {
            if(!_initialized || !Enabled) return false;
            return ReInput.players.GetPlayer(playerId).GetButton(_actionIds[(int)action]);
        }

        public override bool GetButtonDown(int playerId, global::RexEngine.InputAction action) {
            if(!_initialized || !Enabled) return false;
            return ReInput.players.GetPlayer(playerId).GetButtonDown(_actionIds[(int)action]);
        }

        public override bool GetButtonUp(int playerId, global::RexEngine.InputAction action) {
            if(!_initialized || !Enabled) return false;
            return ReInput.players.GetPlayer(playerId).GetButtonUp(_actionIds[(int)action]);
        }

        public override float GetAxis(int playerId, global::RexEngine.InputAction action) {
            if(!_initialized || !Enabled) return 0f;
            return ReInput.players.GetPlayer(playerId).GetAxis(_actionIds[(int)action]);
        }

        // Private methods

        private void CheckHideTouchControlsWhenJoystickConnected() {
            if(!_hideTouchControlsWhenJoysticksConnected) return;

            if(_autoTouchControlUI_isActive) {
                // Disable touch controls if a joystick is connected
                if(Rewired.ReInput.controllers.joystickCount > 0) {
                    _autoTouchControlUI_isActive = false;
                }
            } else {
                // Enable touch controls if no joysticks are connected
                if(Rewired.ReInput.controllers.joystickCount == 0) {
                    _autoTouchControlUI_isActive = true;
                }
            }

            EvaluateTouchControlsActive();
        }

        private void EvaluateTouchControlsActive() {
            // Set the active state on the touch controls based on the external state and the auto state
            // Only set active if both external and internal are active
            SetTouchControlsActive(showTouchControls);
        }

        private void SetTouchControlsActive(bool active) {
            if(_touchControls == null) return;
            if(_touchControls.activeInHierarchy == active) return;
            _touchControls.SetActive(active);
        }

        private void OnControllerConnected(Rewired.ControllerStatusChangedEventArgs args) {
            if(args.controllerType != ControllerType.Joystick) return;
            CheckHideTouchControlsWhenJoystickConnected();
        }

        private void OnControllerDisconnected(Rewired.ControllerStatusChangedEventArgs args) {
            if(args.controllerType != ControllerType.Joystick) return;
            CheckHideTouchControlsWhenJoystickConnected();
        }

        private static void AddRewiredActionId(Dictionary<int, int> actionIds, string actionName, global::RexEngine.InputAction action) {
            int id = GetRewiredActionId(actionName);
            if(id < 0) return; // invalid Action id
            actionIds.Add((int)action, id);
        }

        private static int GetRewiredActionId(string actionName) {
            if(string.IsNullOrEmpty(actionName)) return -1;
            int id = ReInput.mapping.GetActionId(actionName);
            if(id < 0) Debug.LogWarning(className + ": No Rewired Action found for Action name \"" + actionName + "\". The Action name must match exactly to an Action defined in the Rewired Input Manager.");
            return id;
        }

        private enum PlatformFlags {
            None = 0,
            Editor = 1,
            Windows = 1 << 1,
            OSX = 1 << 2,
            Linux = 1 << 3,
            IOS = 1 << 4,
            TVOS = 1 << 5,
            Android = 1 << 6,
            Windows8Store = 1 << 7,
            WindowsUWP10 = 1 << 8,
            WebGL = 1 << 9,
            PS4 = 1 << 10,
            PSVita = 1 << 11,
            Xbox360 = 1 << 12,
            XboxOne = 1 << 13,
            SamsungTV = 1 << 14,
            WiiU = 1 << 15,
            Nintendo3DS = 1 << 16,
            Switch = 1 << 17,
            AmazonFireTV = 1 << 18,
            RazerForgeTV = 1 << 19,
            Unknown = 1 << 31
        }
    }
}